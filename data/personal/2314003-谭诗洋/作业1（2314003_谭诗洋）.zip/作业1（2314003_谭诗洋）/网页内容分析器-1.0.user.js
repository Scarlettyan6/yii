// ==UserScript==
// @name         网页内容分析器
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  分析网页内容，统计字数、图片数量、链接数量，并提供阅读时间估算
// @author       You
// @match        *://*/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // 加载jQuery
    function loadjQuery() {
        return new Promise((resolve) => {
            if (window.jQuery) {
                resolve(window.jQuery);
                return;
            }
            const script = document.createElement('script');
            script.src = 'https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js';
            script.onload = () => resolve(window.jQuery);
            document.head.appendChild(script);
        });
    }

    // 分析网页内容
    function analyzeContent($) {
        // 获取主要内容区域（排除导航、页脚等）
        const mainContent = $('body').clone();
        mainContent.find('nav, footer, header, script, style, .ad, [class*="nav"], [class*="menu"]').remove();

        const text = mainContent.text().replace(/\s+/g, ' ').trim();
        const wordCount = text.length;
        const chineseCharCount = (text.match(/[\u4e00-\u9fa5]/g) || []).length;
        const englishWordCount = (text.match(/\b[a-zA-Z]+\b/g) || []).length;

        // 统计其他元素
        const imageCount = $('img').length;
        const linkCount = $('a').length;
        const headingCount = $('h1, h2, h3, h4, h5, h6').length;

        // 修正：根据总字符数计算阅读时间（平均阅读速度约300-500字/分钟）
        // 这里使用400字/分钟作为标准
        const readingTime = Math.ceil(wordCount / 400);

        return {
            wordCount,
            chineseCharCount,
            englishWordCount,
            imageCount,
            linkCount,
            headingCount,
            readingTime: readingTime || 1, // 至少1分钟
            textSample: text.substring(0, 15) + '...'
        };
    }

    // 创建分析面板
    function createAnalysisPanel($, data) {
        const panel = $('<div>').css({
            'position': 'fixed',
            'top': '20px',
            'right': '20px',
            'background': 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
            'color': 'white',
            'padding': '15px',
            'border-radius': '10px',
            'box-shadow': '0 8px 25px rgba(0,0,0,0.3)',
            'z-index': '10000',
            'font-family': 'Arial, sans-serif',
            'font-size': '14px',
            'min-width': '280px',
            'max-width': '350px',
            'backdrop-filter': 'blur(10px)'
        });

        const closeBtn = $('<button>').text('×').css({
            'position': 'absolute',
            'top': '5px',
            'right': '10px',
            'background': 'none',
            'border': 'none',
            'color': 'white',
            'font-size': '18px',
            'cursor': 'pointer'
        }).click(() => panel.remove());

        const title = $('<h3>').text('网页分析报告').css({
            'margin': '0 0 15px 0',
            'font-size': '16px',
            'border-bottom': '1px solid rgba(255,255,255,0.3)',
            'padding-bottom': '8px'
        });

        const content = `
            <div style="line-height: 1.6;">
                <div>总字符数: <b>${data.wordCount.toLocaleString()}</b></div>
                <div>中文字符: <b>${data.chineseCharCount.toLocaleString()}</b></div>
                <div>英文单词: <b>${data.englishWordCount.toLocaleString()}</b></div>
                <div>图片数量: <b>${data.imageCount}</b></div>
                <div>链接数量: <b>${data.linkCount}</b></div>
                <div>标题数量: <b>${data.headingCount}</b></div>
                <div>阅读时间: <b>约 ${data.readingTime} 分钟</b></div>
                <div style="font-size: 12px; opacity: 0.8;">(按400字/分钟计算)</div>
            </div>
            <div style="margin-top: 12px; padding: 8px; background: rgba(255,255,255,0.1); border-radius: 5px; font-size: 12px;">
                <div style="margin-bottom: 5px;"><b>内容预览:</b></div>
                <div style="max-height: 60px; overflow: hidden;">${data.textSample}</div>
            </div>
        `;

        panel.append(closeBtn, title, content);
        $('body').append(panel);

        // 添加拖拽功能
        let isDragging = false;
        let offset = { x: 0, y: 0 };

        panel.on('mousedown', (e) => {
            isDragging = true;
            offset.x = e.clientX - panel.offset().left;
            offset.y = e.clientY - panel.offset().top;
            panel.css('cursor', 'grabbing');
        });

        $(document).on('mousemove', (e) => {
            if (isDragging) {
                panel.css({
                    left: e.clientX - offset.x,
                    top: e.clientY - offset.y,
                    right: 'auto'
                });
            }
        });

        $(document).on('mouseup', () => {
            isDragging = false;
            panel.css('cursor', 'grab');
        });
    }

    // 初始化
    loadjQuery().then(($) => {
        console.log('网页内容分析器已加载');

        // 等待页面完全加载
        setTimeout(() => {
            const analysisData = analyzeContent($);
            console.log('网页分析结果:', analysisData);

            createAnalysisPanel($, analysisData);

        }, 1000);
    });

})();