document.getElementById('clearHighlights').addEventListener('click', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs.length > 0) {
      // 发送消息到 content script
      chrome.tabs.sendMessage(tabs[0].id, { action: "clearHighlights" });
    }
  });
});