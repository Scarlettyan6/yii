// content.js

document.addEventListener("mouseup", () => {
  const selection = window.getSelection();
  if (selection.rangeCount > 0 && !selection.isCollapsed) {
    const range = selection.getRangeAt(0);

    if (containsHighlight(range)) {
      removeHighlightsInRange(range);
    } else {
      highlightRange(range);
    }

    selection.removeAllRanges();
  }
});

// 判断选区中是否有高亮
function containsHighlight(range) {
  const contents = range.cloneContents();
  return contents.querySelector("span.highlight") !== null;
}

// 高亮任意选区
function highlightRange(range) {
  const span = document.createElement("span");
  span.style.backgroundColor = "yellow";
  span.className = "highlight";

  const contents = range.extractContents(); // 取出选区内容
  span.appendChild(contents);              // 包进 span
  range.insertNode(span);                  // 再放回页面
}

// 移除选区中的高亮（支持部分）
function removeHighlightsInRange(range) {
  const highlights = document.querySelectorAll("span.highlight");

  highlights.forEach(span => {
    if (range.intersectsNode(span)) {
      const parent = span.parentNode;
      while (span.firstChild) {
        parent.insertBefore(span.firstChild, span);
      }
      parent.removeChild(span);
      parent.normalize();
    }
  });
}

// 接收 popup 指令：清除所有高亮
chrome.runtime.onMessage.addListener((message) => {
  if (message.action === "clearHighlights") {
    clearAllHighlights();
  }
});

function clearAllHighlights() {
  const highlights = document.querySelectorAll("span.highlight");
  highlights.forEach(span => {
    const parent = span.parentNode;
    while (span.firstChild) {
      parent.insertBefore(span.firstChild, span);
    }
    parent.removeChild(span);
    parent.normalize();
  });
}
