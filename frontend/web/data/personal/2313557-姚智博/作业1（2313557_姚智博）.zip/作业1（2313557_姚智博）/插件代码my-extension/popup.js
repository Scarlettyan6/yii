function withActiveTab(cb) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs && tabs[0];
    if (!tab || !tab.id) {
      document.getElementById("msg").textContent = "未找到当前标签页";
      return;
    }
    cb(tab.id);
  });
}

function send(cmd) {
  withActiveTab((tabId) => {
    chrome.tabs.sendMessage(tabId, { cmd }, (resp) => {
      // 某些页面（chrome:// 等）content script 不会运行，会报错
      if (chrome.runtime.lastError) {
        document.getElementById("msg").textContent =
          "发送失败：该页面可能禁止注入脚本。\n" +
          chrome.runtime.lastError.message;
        return;
      }
      document.getElementById("msg").textContent = resp ? (resp.msg || JSON.stringify(resp)) : "无返回";
    });
  });
}

document.getElementById("btnNight").addEventListener("click", () => send("toggleNight"));
document.getElementById("btnFocus").addEventListener("click", () => send("toggleFocus"));
document.getElementById("btnCount").addEventListener("click", () => send("countWords"));
