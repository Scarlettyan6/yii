let nightOn = false;
let focusOn = false;

function ensureStyle(id, cssText) {
  let el = document.getElementById(id);
  if (!el) {
    el = document.createElement("style");
    el.id = id;
    el.type = "text/css";
    document.head.appendChild(el);
  }
  el.textContent = cssText;
}

function toggleNight() {
  nightOn = !nightOn;
  if (nightOn) {
    ensureStyle("__hw_night__", `
      html, body { background: #111 !important; color: #e8e8e8 !important; }
      img, video { filter: brightness(0.85) contrast(1.05) !important; }
      a { color: #8ab4f8 !important; }
      * { background-color: transparent !important; }
    `);
  } else {
    const el = document.getElementById("__hw_night__");
    if (el) el.remove();
  }
  return nightOn;
}

function toggleFocus() {
  focusOn = !focusOn;
  if (focusOn) {
    ensureStyle("__hw_focus__", `
      img, video, iframe { display: none !important; }
    `);
  } else {
    const el = document.getElementById("__hw_focus__");
    if (el) el.remove();
  }
  return focusOn;
}

function countWords() {
  const text = (document.body && document.body.innerText) ? document.body.innerText : "";
  const noSpace = text.replace(/\s+/g, "");
  // 粗略统计：字符数（去空格）
  const charCount = noSpace.length;
  // 粗略英文词数：用空白分割
  const enWords = text.trim() ? text.trim().split(/\s+/).length : 0;
  return { charCount, enWords };
}

chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
  if (!req || !req.cmd) return;

  if (req.cmd === "toggleNight") {
    const on = toggleNight();
    sendResponse({ msg: on ? "夜间模式：已开启" : "夜间模式：已关闭" });
  } else if (req.cmd === "toggleFocus") {
    const on = toggleFocus();
    sendResponse({ msg: on ? "专注模式：已开启（已隐藏图片/视频）" : "专注模式：已关闭" });
  } else if (req.cmd === "countWords") {
    const r = countWords();
    sendResponse({ msg: `字数统计（粗略）：\n- 去空格字符数：${r.charCount}\n- 英文词数：${r.enWords}` });
  }
});
